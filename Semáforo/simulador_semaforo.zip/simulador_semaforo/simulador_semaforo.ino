/*
 * UNIVERSIDAD DEL PACÍFICO
 *
 * Proyecto:
 * Sistema Inteligente de Control Vehicular
 *
 * Microcontrolador:
 * Arduino Mega 2560
 *
 * Descripción:
 * Definición de estructuras, pines, constantes y configuración inicial.
 */

#include <Arduino.h>

struct Semaforo {
  byte verde;
  byte amarillo;
  byte rojo;
};

struct Grupo {
  byte carrilA;
  byte carrilB;
};

Semaforo carril[8] = {
  { 22, 23, 24 },  // Carril 1
  { 25, 26, 27 },  // Carril 2
  { 28, 29, 30 },  // Carril 3
  { 31, 32, 33 },  // Carril 4
  { 34, 35, 36 },  // Carril 5
  { 37, 38, 39 },  // Carril 6
  { 40, 41, 42 },  // Carril 7
  { 43, 44, 45 }   // Carril 8
};

const byte sensor[8] = { 2, 3, 4, 5, 6, 7, 8, 9 };

Grupo grupo[4] = {
  { 0, 4 },
  { 1, 5 },
  { 2, 6 },
  { 3, 7 }
};

bool solicitud[8];

byte grupoActual = 0;
byte grupoSiguiente = 0;

const unsigned long TIEMPO_VERDE = 10000;
const unsigned long TIEMPO_AMARILLO = 3000;

enum EstadoSemaforo { ESPERA,
                      VERDE,
                      AMARILLO };

EstadoSemaforo estado = ESPERA;

unsigned long tiempoAnterior = 0;

void configurarPines();
void leerSensores();
void todosRojo();
void ponerVerde(byte grupo);
void ponerAmarillo(byte actual, byte siguiente);
void apagarVerde(byte grupo);
bool haySolicitudes();
byte buscarGrupo();
void limpiarGrupo(byte grupo);

void setup() {
  configurarPines();
  todosRojo();
}

void configurarPines() {
  for (byte i = 0; i < 8; i++) {
    pinMode(carril[i].verde, OUTPUT);
    pinMode(carril[i].amarillo, OUTPUT);
    pinMode(carril[i].rojo, OUTPUT);
  }

  // Configurar sensores (pulsadores)
  for (byte i = 0; i < 8; i++) {
    pinMode(sensor[i], INPUT_PULLUP);
    solicitud[i] = false;
  }
}

void leerSensores() {
  static bool estadoAnterior[8] = {
    HIGH, HIGH, HIGH, HIGH,
    HIGH, HIGH, HIGH, HIGH
  };

  for (byte i = 0; i < 8; i++) {
    bool lectura = digitalRead(sensor[i]);

    // Registrar solo cuando se presiona el pulsador
    if (estadoAnterior[i] == HIGH && lectura == LOW) {
      solicitud[i] = true;
    }
    estadoAnterior[i] = lectura;
  }
}

void todosRojo() {
  for (byte i = 0; i < 8; i++) {
    digitalWrite(carril[i].verde, LOW);
    digitalWrite(carril[i].amarillo, LOW);
    digitalWrite(carril[i].rojo, HIGH);
  }
}

void ponerVerde(byte g) {

  byte a = grupo[g].carrilA;
  byte b = grupo[g].carrilB;

  // Carril A
  digitalWrite(carril[a].rojo, LOW);
  digitalWrite(carril[a].amarillo, LOW);
  digitalWrite(carril[a].verde, HIGH);

  // Carril B
  digitalWrite(carril[b].rojo, LOW);
  digitalWrite(carril[b].amarillo, LOW);
  digitalWrite(carril[b].verde, HIGH);
}

void ponerAmarillo(byte actual, byte siguiente) {

  byte a1 = grupo[actual].carrilA;
  byte b1 = grupo[actual].carrilB;

  byte a2 = grupo[siguiente].carrilA;
  byte b2 = grupo[siguiente].carrilB;

  // Grupo que termina
  digitalWrite(carril[a1].verde, LOW);
  digitalWrite(carril[a1].amarillo, HIGH);
  digitalWrite(carril[a1].rojo, LOW);

  digitalWrite(carril[b1].verde, LOW);
  digitalWrite(carril[b1].amarillo, HIGH);
  digitalWrite(carril[b1].rojo, LOW);

  // Grupo que inicia
  digitalWrite(carril[a2].verde, LOW);
  digitalWrite(carril[a2].amarillo, HIGH);
  digitalWrite(carril[a2].rojo, LOW);

  digitalWrite(carril[b2].verde, LOW);
  digitalWrite(carril[b2].amarillo, HIGH);
  digitalWrite(carril[b2].rojo, LOW);
}

bool haySolicitudes() {
  for (byte i = 0; i < 8; i++) {
    if (solicitud[i]) {
      return true;
    }
  }

  return false;
}

byte buscarGrupo() {
  for (byte g = 0; g < 4; g++) {
    byte a = grupo[g].carrilA;
    byte b = grupo[g].carrilB;

    if (solicitud[a] || solicitud[b]) {
      return g;
    }
  }

  return 0;
}

void limpiarGrupo(byte g) {
  byte a = grupo[g].carrilA;
  byte b = grupo[g].carrilB;

  solicitud[a] = false;
  solicitud[b] = false;
}

void loop() {

  leerSensores();

  switch (estado) {
    case ESPERA:
      {
        if (haySolicitudes()) {
          grupoActual = buscarGrupo();
          ponerVerde(grupoActual);
          tiempoAnterior = millis();
          estado = VERDE;
        }
        break;
      }

    case VERDE:
      {
        if (millis() - tiempoAnterior >= TIEMPO_VERDE) {
          if (haySolicitudes()) {
            grupoSiguiente = buscarGrupo();
          } else {
            grupoSiguiente = grupoActual;
          }

          ponerAmarillo(grupoActual, grupoSiguiente);

          tiempoAnterior = millis();
          estado = AMARILLO;
        }

        break;
      }
    case AMARILLO:
      {

        if (millis() - tiempoAnterior >= TIEMPO_AMARILLO) {

          byte a1 = grupo[grupoActual].carrilA;
          byte b1 = grupo[grupoActual].carrilB;

          byte a2 = grupo[grupoSiguiente].carrilA;
          byte b2 = grupo[grupoSiguiente].carrilB;

          // Grupo que termina -> Rojo
          digitalWrite(carril[a1].verde, LOW);
          digitalWrite(carril[a1].amarillo, LOW);
          digitalWrite(carril[a1].rojo, HIGH);

          digitalWrite(carril[b1].verde, LOW);
          digitalWrite(carril[b1].amarillo, LOW);
          digitalWrite(carril[b1].rojo, HIGH);

          // Grupo que inicia -> Verde
          digitalWrite(carril[a2].verde, HIGH);
          digitalWrite(carril[a2].amarillo, LOW);
          digitalWrite(carril[a2].rojo, LOW);

          digitalWrite(carril[b2].verde, HIGH);
          digitalWrite(carril[b2].amarillo, LOW);
          digitalWrite(carril[b2].rojo, LOW);

          grupoActual = grupoSiguiente;

          limpiarGrupo(grupoActual);

          tiempoAnterior = millis();
          estado = VERDE;
        }

        break;
      }
  }
}